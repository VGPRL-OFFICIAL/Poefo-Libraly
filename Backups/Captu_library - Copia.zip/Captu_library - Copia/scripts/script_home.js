// scripts/script_home.js

// --- URLs e Constantes ---
function getBaseDadosPath(file) {
    // Ajuste este caminho se a estrutura de pastas for diferente
    return '../base_dados/' + file;
}

// O arquivo livros.json LOCAL é mantido apenas para popular o booksMap, que alimenta
// as seções de ID (Recomendados, Top 10 e Lançamentos). O array completo NÃO será mais usado para renderização.
const ALL_BOOKS_DATA_URL = getBaseDadosPath('livros.json');
const RECOMENDADOS_IDS_URL = getBaseDadosPath('recomendados.json');
const TOP_10_IDS_URL = getBaseDadosPath('top_10.json');
const FEATURED_IDS_URL = getBaseDadosPath('lancamentos.json');

// Link Estático Principal para "Todos os Livros"
const LIVROS_API_URL = 'https://firebasestorage.googleapis.com/v0/b/captu-libraly.firebasestorage.app/o/livros_json%2Flivros.json?alt=media&token=3eaf739c-b9fc-45b7-ab15-800d9058655a';

// Elementos DOM
const recomendadosListElement = document.getElementById('recomendados-list');
const top10ListElement = document.getElementById('top-10-list');
const featuredCardElement = document.getElementById('featured-card-container');
const allBooksGridElement = document.getElementById('all-books-grid');
// O elemento livrosApiListElement não é mais necessário, mas será mantido como variável nula 
// ou removido, dependendo da necessidade de outras partes do código. Para este script, vamos remover a variável DOM não utilizada.
// const livrosApiListElement = document.getElementById('livros-api-list'); // REMOVIDO

// Armazenamento global dos dados locais por ID
let booksMap = new Map();

// --- Funções Auxiliares ---

async function fetchData(url) {
    const response = await fetch(url);
    if (!response.ok) {
        throw new Error(`Erro ao buscar ${url}. Status: ${response.status}`);
    }
    return response.json();
}

// --- Funções de Renderização (Mantidas) ---

function renderBookItem(bookData, index) {
    let title = bookData.titulo || "Título Não Informado";
    let author = bookData.autor || "Autor Desconhecido";
    let coverUrl = bookData.link_capa;

    let filterStyle = '';
    if (index % 3 === 0) filterStyle = 'filter: brightness(1.0);';
    else if (index % 3 === 1) filterStyle = 'filter: brightness(0.9);';
    else if (index % 3 === 2) filterStyle = 'filter: brightness(1.1);';

    return `
 <div class="book-item" data-book='${encodeURIComponent(JSON.stringify(bookData))}' style="cursor:pointer;">
 <div class="book-cover" style="background-image: url('${coverUrl || '../images/cover_placeholder.jpg'}'); ${filterStyle}"></div>
          <div class="book-info">
            <div class="book-title">${title}</div>
 <div class="book-author">${author}</div>
</div>
 </div>
`;
}

function renderSpecialBookItem(bookData) {
    let title = bookData.titulo || "Título Não Informado";
    let author = bookData.autor || "Autor Desconhecido";
    let likes = bookData.likes || '0';
    let coverUrl = bookData.link_capa;

    return `
 <div class="book-item book-item-with-zero" data-book='${encodeURIComponent(JSON.stringify(bookData))}' style="cursor:pointer;">
 <div class="book-cover jos-cover" style="background-image: url('${coverUrl || '../images/cover_placeholder.jpg'}');"></div>
 <div class="book-info">
<div class="book-author">${title}</div>
 <div class="book-author zero-count">${likes}</div>
 <div class="book-author sub-author">${author}</div>
 </div>
 </div>
 `;
}

function renderFeaturedCard(bookData) {
    let title = (bookData.titulo || "NOVO LANÇAMENTO").toUpperCase();
    let description = bookData.sinopse || "";
    let likes = bookData.likes || '0';
    let coverUrl = bookData.link_capa;
    const fixedDescription = "Detalhes não disponíveis. Clique para saber mais...";
    const finalDescription = description.length > 50 ? description : fixedDescription;

    return `
 <div class="featured-card book-item" data-book='${encodeURIComponent(JSON.stringify(bookData))}' style="cursor:pointer;">
 <div class="featured-cover" style="background-image: url('${coverUrl || '../images/placeholder.jpg'}');"></div>
 <div class="featured-overlay">
<p class="overlay-title">${title}</p>
 <p class="overlay-description">
${finalDescription}
</p>
 <p class="overlay-like">${likes}</p>
 </div>
 </div>
 `;
}

// --- Listener Global de Clique (Mantido) ---

document.addEventListener('DOMContentLoaded', function () {
    function handleBookClick(e) {
        let el = e.target;
        while (el && el !== document.body) {
            if (el.classList.contains('book-item') && el.hasAttribute('data-book')) {
                try {
                    const bookData = JSON.parse(decodeURIComponent(el.getAttribute('data-book')));

                    sessionStorage.setItem('selectedBook', JSON.stringify(bookData));

                    window.location.href = './livro.html';
                } catch (err) {
                    console.error('Erro ao processar clique no livro', err);
                }
                e.preventDefault();
                e.stopPropagation();
                return;
            }
            el = el.parentElement;
        }
    }

    document.body.addEventListener('click', handleBookClick);
});

// --- FUNÇÃO PARA CARREGAR E RENDERIZAR TODOS OS LIVROS (Do Link Estático) ---

async function loadAllBooksFromApi() {
    allBooksGridElement.innerHTML = `<p class="loading-message">Carregando todos os livros...</p>`;

    try {
        // Busca os dados diretamente do link estático (LIVROS_API_URL)
        const allBooksArray = await fetchData(LIVROS_API_URL);

        if (!allBooksArray || allBooksArray.length === 0) {
            allBooksGridElement.innerHTML = `<p class="error-message">Nenhum livro encontrado na fonte principal.</p>`;
            return;
        }

        let allBooksHTML = '';
        allBooksArray.forEach((book, index) => {
            // Mantém a lógica do item especial (ID 5)
            const isSpecialItem = book.id === 5;

            if (isSpecialItem) {
                allBooksHTML += renderSpecialBookItem(book);
            } else {
                allBooksHTML += renderBookItem(book, index);
            }
        });
        allBooksGridElement.innerHTML = allBooksHTML;

    } catch (error) {
        console.error("Erro ao carregar todos os livros do link estático:", error);
        allBooksGridElement.innerHTML = `<p class="error-message">Falha ao carregar todos os livros. Detalhe: ${error.message}</p>`;
    }
}


// --- FUNÇÃO PRINCIPAL DE CARREGAMENTO (Atualizada) ---

async function loadBooks() {
    try {
        // 1. Carrega todos os livros locais e popula o Mapa (Apenas para as seções baseadas em IDs)
        // O array completo NÃO será mais usado para renderização da grade.
        const allBooksArrayLocal = await fetchData(ALL_BOOKS_DATA_URL);

        if (allBooksArrayLocal && allBooksArrayLocal.length > 0) {
            booksMap = new Map(allBooksArrayLocal.map(book => [book.id, book]));
        } else {
            console.warn("Aviso: O arquivo livros.json local está vazio. Seções dependentes de IDs podem falhar.");
        }

        // 2. Carrega as três listas de IDs em paralelo
        const [recomendadosIds, top10Ids, featuredIds] = await Promise.all([
            fetchData(RECOMENDADOS_IDS_URL),
            fetchData(TOP_10_IDS_URL),
            fetchData(FEATURED_IDS_URL)
        ]);

        // --- RENDERIZAÇÃO DAS SEÇÕES (Usando dados locais do booksMap) ---

        // 3. RECOMENDADOS 
        if (recomendadosIds && recomendadosIds.length > 0) {
            const recomendadosToRender = recomendadosIds
                .map(id => booksMap.get(id))
                .filter(book => book !== undefined);

            recomendadosListElement.innerHTML = recomendadosToRender.map((book, index) => renderBookItem(book, index)).join('');
        } else {
            recomendadosListElement.innerHTML = `<p class="error-message">Nenhuma recomendação encontrada.</p>`;
        }

        // 4. TOP 10 LIVROS
        if (top10Ids && top10Ids.length > 0) {
            const topBooksToRender = top10Ids
                .map(id => booksMap.get(id))
                .filter(book => book !== undefined);

            top10ListElement.innerHTML = topBooksToRender.map((book, index) => renderBookItem(book, index)).join('');
        } else {
            top10ListElement.innerHTML = `<p class="error-message">Nenhum livro listado no Top 10.</p>`;
        }

        // 5. LANÇAMENTOS (Item em destaque)
        if (featuredIds && featuredIds.length > 0) {
            const featuredBook = booksMap.get(featuredIds[0]);
            if (featuredBook) {
                featuredCardElement.innerHTML = renderFeaturedCard(featuredBook);
            } else {
                featuredCardElement.innerHTML = `<p class="error-message">ID de lançamento não encontrado no acervo.</p>`;
            }
        } else {
            featuredCardElement.innerHTML = `<p class="error-message">Nenhum lançamento definido.</p>`;
        }

        // 6. TODOS OS LIVROS (Grade) - AGORA USA O LINK ESTÁTICO (LIVROS_API_URL)
        await loadAllBooksFromApi();

        // 7. CARREGA LIVROS DA API EXTERNA (REMOVIDO: Chamada loadLivrosApi() removida daqui)

    } catch (error) {
        console.error("Erro crítico ao carregar dados:", error);
        const msg = `<p style="padding: 20px; color: red; text-align: center;">ERRO CRÍTICO: Falha ao carregar a biblioteca. Detalhe: ${error.message}</p>`;
        document.querySelector('.main-screen').innerHTML = msg;
    }
}

// REMOVIDO: A função loadLivrosApi() anterior não é mais necessária, 
// pois sua lógica foi integrada na loadAllBooksFromApi().

// Inicia o carregamento quando o DOM estiver completamente carregado
document.addEventListener('DOMContentLoaded', loadBooks);