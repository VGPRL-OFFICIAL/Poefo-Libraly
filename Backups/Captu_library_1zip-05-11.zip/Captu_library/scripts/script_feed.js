document.addEventListener('DOMContentLoaded', () => {
    // Dados JSON fornecidos para o exemplo do livro VAGABOND
    const bookDataVagabond = {
        "sinopse": "Musashi Miyamoto segue seu caminho para se tornar o maior samurai. Sua jornada o leva a um confronto com o formidável Mestre Seijuro Yoshioka.",
        "link_capa": "https://firebasestorage.googleapis.com/v0/b/zion-mega-store.appspot.com/o/r.s.poefo%2Flivros%2FCapas%2FScreenshot_20250828_204958_Samsung%20Notes.jpg?alt=media&token=f6926d3d-9cfa-4b99-ba42-dabc9a89d5cc",
        "genero": "Samurais, Ação, Histórico, Drama, Seinen",
        "link_acesso": "https://drive.google.com/file/d/1bTDMJUjClnym_f4z4SpHAXke92Nl9hzS/view?usp=drivesdk",
        "titulo": "VAGABOND vol.2",
        "classificacao": "18",
        "comentarios": "https://firebasestorage.googleapis.com/v0/b/zion-mega-store.appspot.com/o/r.s.poefo%2Flivros%2Fcomentarios_livros%2Fcomentario_num_8647534658797587?alt=media&token=f275bcb8-a55c-4d79-9dc5-6a4225fe5470",
        "autor": "Takehiko Inoue",
        "likes": "120"
    };

    // Segundo post de livro (exemplo)
    const bookDataExample = {
        "sinopse": "Uma jornada épica de fantasia medieval e magia.",
        "link_capa": "https://picsum.photos/100/150?random=fantasy",
        "genero": "Fantasia, Aventura, Magia",
        "link_acesso": "#",
        "titulo": "O Último Mago",
        "classificacao": "14",
        "autor": "A. C. Smith",
        "likes": "45"
    };

    const postsContainer = document.getElementById('posts-container');

    /**
     * Cria e retorna o elemento HTML para o anexo de livro.
     */
    function createBookAttachment(data) {
        const attachment = document.createElement('a');
        attachment.href = data.link_acesso;
        attachment.target = "_blank";
        attachment.classList.add('post-attachment', 'book-attachment');

        const cover = document.createElement('img');
        cover.src = data.link_capa;
        cover.alt = `Capa do Livro: ${data.titulo}`;
        cover.classList.add('book-cover');
        
        const info = document.createElement('div');
        info.classList.add('book-info');
        
        const title = document.createElement('p');
        title.classList.add('book-title');
        title.textContent = data.titulo;
        
        const author = document.createElement('p');
        author.classList.add('book-author');
        author.textContent = `Por: ${data.autor} (${data.classificacao}+)`;
        
        const genre = document.createElement('p');
        genre.classList.add('book-genre');
        genre.textContent = data.genero.split(', ')[0];

        info.appendChild(title);
        info.appendChild(author);
        info.appendChild(genre);
        
        attachment.appendChild(cover);
        attachment.appendChild(info);
        
        return attachment;
    }

    /**
     * Cria uma publicação completa com anexo de livro.
     */
    function createBookPost(data, text, username, handle, time) {
        const post = document.createElement('div');
        post.classList.add('post');

        const avatar = document.createElement('div');
        avatar.classList.add('avatar');
        post.appendChild(avatar);

        const content = document.createElement('div');
        content.classList.add('post-content');

        const header = document.createElement('div');
        header.classList.add('post-header');
        header.innerHTML = `
            <span class="username">${username}</span>
            <span class="handle">${handle}</span>
            <span class="time">${time}</span>
        `;
        content.appendChild(header);

        const postText = document.createElement('p');
        postText.classList.add('post-text');
        postText.textContent = text;
        content.appendChild(postText);

        if (data) {
            content.appendChild(createBookAttachment(data));
        }
        
        const actions = document.createElement('div');
        actions.classList.add('post-actions');
        actions.innerHTML = `
            <span class="action"><i class="far fa-comment"></i> ${Math.floor(Math.random() * 10) + 1}</span>
            <span class="action"><i class="fas fa-retweet"></i> ${Math.floor(Math.random() * 20) + 5}</span>
            <span class="action"><span class="like-button"><i class="far fa-heart"></i> ${data ? data.likes : Math.floor(Math.random() * 100) + 20}</span></span>
            <span class="action"><i class="fas fa-share-alt"></i></span>
        `;
        content.appendChild(actions);
        
        // Adicionar seção de comentários para o post principal
        if (data === bookDataVagabond) {
             const comments = document.createElement('div');
             comments.classList.add('comments-section');
             comments.innerHTML = `
                  <p class="comment-count">Ver 1 comentário</p>
                  <div class="comment-item">
                      <span class="comment-user">@SamuraiFan:</span>
                      <span class="comment-text">Essa luta é épica! Inoue é gênio!</span>
                  </div>
             `;
             content.appendChild(comments);
        }

        post.appendChild(content);
        return post;
    }

    // Array de todos os posts fixos no HTML
    const htmlPosts = Array.from(postsContainer.children);

    // 1. Inserir a publicação principal (VAGABOND) no topo (posição 0)
    const vagabondPost = createBookPost(
        bookDataVagabond, 
        `Novo post sobre o Vol.2 de VAGABOND! Uma obra-prima do Takehiko Inoue. O link para o drive está anexado. Classificação: ${bookDataVagabond.classificacao} anos.`,
        "LeitorPro", 
        "@leitor_pro", 
        "1 min atrás"
    );
    postsContainer.prepend(vagabondPost);

    // 2. Inserir a segunda publicação de livro em uma posição intermediária (após o primeiro post fixo)
    const exampleBookPost = createBookPost(
        bookDataExample,
        `Recomendação de leitura de fantasia: "${bookDataExample.titulo}". Leve e imersivo. Gênero: ${bookDataExample.genero.split(', ')[0]}.`,
        "Recomendador", 
        "@livros_e_mais", 
        "ontem"
    );
    // Insere na posição 3 (Após o post fixo 1 e 2)
    if (htmlPosts.length >= 2) {
        postsContainer.insertBefore(exampleBookPost, htmlPosts[1]);
    } else {
         postsContainer.appendChild(exampleBookPost);
    }
    
    // 3. Adicionar funcionalidade de like (exemplo) a todos os botões
    document.querySelectorAll('.like-button').forEach(button => {
        button.addEventListener('click', (e) => {
            const icon = e.currentTarget.querySelector('i');
            
            if (icon.classList.contains('fas')) { 
                icon.classList.remove('fas');
                icon.classList.add('far');
                icon.style.color = 'var(--text-color-subtle)'; 
            } else {
                icon.classList.remove('far');
                icon.classList.add('fas');
                icon.style.color = '#E0245E';
            }
        });
    });
});