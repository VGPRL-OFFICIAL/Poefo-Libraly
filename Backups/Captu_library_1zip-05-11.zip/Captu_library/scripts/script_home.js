// scripts/script_home.js (Passagem de Dados para a Página de Detalhes)

// URLs e Constantes
function getBaseDadosPath(file) {
    return '../base_dados/' + file;
}

const ALL_BOOKS_URL = getBaseDadosPath('livros.json'); 
const TOP_10_URL = getBaseDadosPath('top_10.json'); 
const FEATURED_URL = getBaseDadosPath('lancamentos.json'); 


// Elementos DOM
const top10ListElement = document.getElementById('top-10-list');
const featuredCardElement = document.getElementById('featured-card-container');
const allBooksGridElement = document.getElementById('all-books-grid');


// --- Funções de Renderização (Mantidas) ---

function renderBookItem(bookData, index) {
    let title = bookData.titulo || "Título Não Informado";
    let author = bookData.autor || "Autor Desconhecido"; 
    let coverUrl = bookData.link_capa;

    let filterStyle = '';
    if (index % 3 === 0) filterStyle = 'filter: brightness(1.0);';
    else if (index % 3 === 1) filterStyle = 'filter: brightness(0.9);';
    else if (index % 3 === 2) filterStyle = 'filter: brightness(1.1);';
    
    // ATENÇÃO: Os dados do livro SÃO codificados no data-book
    return `
        <div class="book-item" data-book='${encodeURIComponent(JSON.stringify(bookData))}' style="cursor:pointer;">
            <div class="book-cover" style="background-image: url('${coverUrl || '../images/vagabond_cover.jpg'}'); ${filterStyle}"></div>
            <div class="book-info">
                <div class="book-title">${title}</div>
                <div class="book-author">${author}</div>
            </div>
        </div>
    `;
}

function renderSpecialBookItem(bookData) {
    let title = bookData.titulo || "Título Não Informado";
    let author = bookData.autor || "Autor Desconhecido";
    let likes = bookData.likes || '0';
    
    return `
        <div class="book-item book-item-with-zero" data-book='${encodeURIComponent(JSON.stringify(bookData))}' style="cursor:pointer;">
            <div class="book-cover jos-cover" style="background-image: url('images/jos_vagabumes.jpg');"></div>
            <div class="book-info">
                <div class="book-author">${title}</div>
                <div class="book-author zero-count">${likes}</div>
                <div class="book-author sub-author">${author}</div>
            </div>
        </div>
    `;
}

function renderFeaturedCard(bookData) {
    let title = (bookData.titulo || "NOVO LANÇAMENTO").toUpperCase();
    // [...] Resto da renderização do Card de Lançamento (Deixado para simplificar)
    let description = bookData.sinopse || "";
    let likes = bookData.likes || '0';
    let coverUrl = bookData.link_capa;
    const fixedDescription = "Takezo Shinmen, um jovem notório por sua violência, é rebatizado como (Musashi Miyamoto) após sua jornada de redenção. Ele se afasta da brutalidade descontrolada e começa a se dedicar ao Bushidô, buscando transformar sua força bruta em habilidade, a fim de se tornar o maior espadachim do Japão.";
    const finalDescription = description.length > 50 ? description : fixedDescription;
    
    // IMPORTANTE: Adiciona o data-book para que o clique funcione
    return `
        <div class="featured-card book-item" data-book='${encodeURIComponent(JSON.stringify(bookData))}' style="cursor:pointer;">
            <div class="featured-cover" style="background-image: url('${coverUrl || 'images/vagabond_vol1.jpg'}');"></div>
            <div class="featured-overlay">
                <p class="overlay-title">${title}</p>
                <p class="overlay-description">
                    ${finalDescription}
                </p>
                <p class="overlay-like">${likes}</p>
            </div>
        </div>
    `;
}

// --- Listener Global de Clique CORRIGIDO ---

document.addEventListener('DOMContentLoaded', function() {
    function handleBookClick(e) {
        let el = e.target;
        while (el && el !== document.body) {
            // Verifica se chegamos ao elemento clicável que contém os dados
            if (el.classList.contains('book-item') && el.hasAttribute('data-book')) {
                try {
                    const bookData = JSON.parse(decodeURIComponent(el.getAttribute('data-book')));
                    
                    // CORREÇÃO ESSENCIAL: Usa sessionStorage e a chave 'selectedBook'
                    sessionStorage.setItem('selectedBook', JSON.stringify(bookData)); 

                    const livroPath = './livro.html';
                    window.location.href = livroPath;
                } catch (err) {
                    console.error('Erro ao processar clique no livro', err);
                    alert('Erro ao abrir detalhes do livro.');
                }
                e.preventDefault(); 
                e.stopPropagation(); 
                return;
            }
            el = el.parentElement;
        }
    }
    
    // Anexa o listener ao corpo do documento para capturar todos os cliques nos itens .book-item
    document.body.addEventListener('click', handleBookClick);
});

// --- FUNÇÃO PRINCIPAL DE CARREGAMENTO (Simplificada, mantendo a busca) ---
async function loadBooks() {
    // [...] O restante da função loadBooks deve permanecer como estava, apenas removendo a chamada ao attachBookItemHandlers, pois o listener é global.
    const fetchData = async (url) => {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`Erro ao buscar ${url}. Status: ${response.status}`);
        }
        return response.json();
    };

    try {
        const [topBooks, featuredList, allBooks] = await Promise.all([
            fetchData(TOP_10_URL),
            fetchData(FEATURED_URL),
            fetchData(ALL_BOOKS_URL)
        ]);

        // 1. TOP 10 LIVROS (Renderização)
        if (topBooks && topBooks.length > 0) {
            const topBooksToRender = [...topBooks]; 
            topBooksToRender.push(topBooks[0]); 
            top10ListElement.innerHTML = topBooksToRender.map((book, index) => renderBookItem(book, index)).join('');
        } else {
            top10ListElement.innerHTML = `<p class="error-message">Nenhum livro encontrado no Top 10.</p>`;
        }

        // 2. LANÇAMENTOS (Item em destaque)
        if (featuredList && featuredList.length > 0) {
            featuredCardElement.innerHTML = renderFeaturedCard(featuredList[0]);
        } else {
             featuredCardElement.innerHTML = `<p class="error-message">Nenhum lançamento encontrado.</p>`;
        }
        
        // 3. TODOS OS LIVROS (Grade)
        if (allBooks && allBooks.length > 0) {
            let allBooksHTML = '';
            allBooks.forEach((book, index) => {
                const isSpecialItem = (book.titulo && book.titulo.includes('O Túmulo dos Vagalumes')) || (book.autor && book.autor.includes('Akiyuki Nosaka'));
                
                if (isSpecialItem) {
                    allBooksHTML += renderSpecialBookItem(book);
                } else {
                    allBooksHTML += renderBookItem(book, index);
                }
            });
            allBooksGridElement.innerHTML = allBooksHTML;
        } else {
            allBooksGridElement.innerHTML = `<p class="error-message">Nenhum livro encontrado na lista completa.</p>`;
        }

    } catch (error) {
        console.error("Erro crítico ao carregar dados:", error);
        const msg = `<p style="padding: 20px; color: red;">ERRO CRÍTICO: Não foi possível carregar os dados. Verifique os caminhos dos arquivos JSON. Detalhe: ${error.message}</p>`;
        top10ListElement.innerHTML = msg;
        if(featuredCardElement) featuredCardElement.innerHTML = `<div style="text-align:center;">${msg}</div>`;
        if(allBooksGridElement) allBooksGridElement.innerHTML = msg;
    }
}

// Inicia o carregamento quando o DOM estiver completamente carregado
document.addEventListener('DOMContentLoaded', loadBooks);