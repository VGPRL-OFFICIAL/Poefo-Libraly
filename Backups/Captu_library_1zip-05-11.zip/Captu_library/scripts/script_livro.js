// script_livro.js
// Implementa o layout simples: Elementos um abaixo do outro.

// Função utilitária para obter dados do livro do localStorage
function getBookData() {
    const sessionData = sessionStorage.getItem('selectedBook');
    if (sessionData) return JSON.parse(sessionData);
    const data = localStorage.getItem('selectedBook');
    return data ? JSON.parse(data) : null;
}

// Função para construir o caminho do ícone de classificação
function getClassificationIconPath(classification) {
    const match = String(classification).match(/\d+/);
    const age = match ? match[0] : 'L';
    return `../images/classification_idication_${age}.png`;
}

function renderBookDetails(book) {
    const container = document.getElementById('book-details-container');
    const bottomBar = document.querySelector('.bottom-bar'); 

    if (!book) {
        container.innerHTML = '<p style="color:red; padding:20px; text-align:center;">Livro não encontrado.</p>';
        if (bottomBar) bottomBar.style.display = 'none'; 
        return;
    }

    // Usando valores padrão
    const coverUrl = book.link_capa || 'https://via.placeholder.com/150x200?text=Capa+Ausente';
    const title = book.titulo || 'Título Não Informado';
    const author = book.autor || 'Autor Desconhecido';
    const sinopse = book.sinopse || 'Sem sinopse disponível.';
    const genero = book.genero || 'Gênero Não Informado';
    const likes = book.likes || '0';
    const divaCount = book.divas || '0'; 
    const saveCount = book.salvos || '0';
    const linkAcesso = book.link_acesso || '';
    const classificationValue = book.classificacao || 'Livre';
    const classificationIconPath = getClassificationIconPath(classificationValue);
    
    const authorLine = `Autor: ${author}`;

    // 1. Renderiza o Conteúdo da Página
    container.innerHTML = `
        <div class="main-content-header" style="--book-cover-url: url('${coverUrl}');">
            </div>

        <div class="book-details-section">
            <img src="${coverUrl}" class="book-cover-large" alt="Capa do Livro">
            <h1 class="book-title-detail">${title}</h1>
            <p class="book-author-detail">${authorLine}</p>
            <p class="book-metadata-tags">${genero}</p>
        </div>

        <div class="read-button-container-central">
            <button id="ler-btn-main" class="ler-btn-main ${!linkAcesso ? 'disabled' : ''}" ${!linkAcesso ? 'disabled' : ''}>Ler Livro</button>
        </div>

        <div class="book-actions-row-simple">
            
            <div class="action-item-simple">
                <i class="fas fa-cloud-download-alt action-icon"></i>
                <span>Diva</span>
                <span class="action-count">${divaCount}</span>
            </div>
            
            <div class="action-item-simple">
                <img src="${classificationIconPath}" alt="Classificação Indicativa" class="classification-icon">
                <span>Class.</span>
            </div>
            
            <div class="action-item-simple">
                <i class="far fa-heart action-icon like-icon"></i>
                <span>Like</span>
                <span class="action-count">${likes}</span>
            </div>

            <div class="action-item-simple">
                <i class="far fa-bookmark action-icon"></i>
                <span>Salvar</span>
                <span class="action-count">${saveCount}</span>
            </div>
        </div>

        <div class="book-section sinopse-section">
            <h3 class="section-title">Sinopse</h3>
            <p class="book-sinopse">${sinopse}</p>
        </div>

        <div class="book-section comments-section">
            <h3 class="section-title">Comentários</h3>
            <p class="book-sinopse">Clique aqui para ver a seção de comentários...</p>
        </div>
        
        <div style="height: 20px;"></div> 
`;
    
    // 2. Configura a funcionalidade do botão 'Ler'
    const lerBtnMain = document.getElementById('ler-btn-main');
    if (lerBtnMain) {
        if (linkAcesso) {
            lerBtnMain.onclick = function() {
                sessionStorage.setItem('readerUrl', linkAcesso);
                window.location.href = './reader.html';
            };
        } else {
            lerBtnMain.onclick = null;
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const book = getBookData();
    renderBookDetails(book);
    
    // Configura o botão Voltar
    const backBtn = document.querySelector('.action-icon-top');
    if (backBtn) {
        backBtn.onclick = function() {
            window.history.back();
        };
    }
});