// script_reader.js
// Lê sessionStorage.readerUrl (ou fallback em selectedBook.link_acesso) e carrega no iframe

function convertToPreview(url) {
    try {
        const gdriveFileMatch = url.match(/\/file\/d\/(.*?)\//);
        if (gdriveFileMatch && gdriveFileMatch[1]) {
            return `https://drive.google.com/file/d/${gdriveFileMatch[1]}/preview`;
        }
        const idMatch = url.match(/[?&]id=([a-zA-Z0-9_-]+)/);
        if (idMatch && idMatch[1]) {
            return `https://drive.google.com/file/d/${idMatch[1]}/preview`;
        }
    } catch (e) {
        // ignore
    }
    return url;
}

function getReaderUrl() {
    let url = sessionStorage.getItem('readerUrl');
    if (url) return url;
    // fallback: try selectedBook
    const sel = sessionStorage.getItem('selectedBook') || localStorage.getItem('selectedBook');
    if (sel) {
        try {
            const book = JSON.parse(sel);
            return book.link_acesso || null;
        } catch (e) { return null; }
    }
    return null;
}

document.addEventListener('DOMContentLoaded', function() {
    const url = getReaderUrl();
    const frame = document.getElementById('pdf-frame');
    const info = document.getElementById('reader-info');
    const openNew = document.getElementById('open-new');
    const backBtn = document.getElementById('back-btn');

    if (!url) {
        info.innerText = 'Nenhuma URL de leitura encontrada.';
        return;
    }

    const preview = convertToPreview(url);
    info.innerText = preview;
    frame.src = preview;

    openNew.addEventListener('click', function() {
        window.open(url, '_blank');
    });

    backBtn.addEventListener('click', function() {
        window.history.back();
    });

    // fallback: se o frame não carregar por CORS, oferecer abrir em nova aba
    frame.onload = function() {
        // nothing
    };

    // Se quiser, limpar sessionStorage.readerUrl após um tempo
    // sessionStorage.removeItem('readerUrl');
});